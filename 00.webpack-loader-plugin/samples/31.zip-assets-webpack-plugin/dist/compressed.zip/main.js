/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
const num = 10;
console.log(num);
/******/ })()
;